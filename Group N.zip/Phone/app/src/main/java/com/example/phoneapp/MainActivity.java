package com.example.phoneapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btnOne, btnTwo, btnThree, btnFour, btnFive, btnStar, btnCall;
    Button btnSix, btnSeven, btnEight, btnNine, btnZero, btnHash;
    ImageButton  btndel;
    EditText input;

    Button btnKey, btnCL, btnCT;

    private static final int REQUEST_CALL = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btndel = findViewById(R.id.btnX);
        btnZero = findViewById(R.id.btn0);
        btnOne = findViewById(R.id.btn1);
        btnTwo = findViewById(R.id.btn2);
        btnThree = findViewById(R.id.btn3);
        btnFour = findViewById(R.id.btn4);
        btnFive = findViewById(R.id.btn5);
        btnSix = findViewById(R.id.btn6);
        btnSeven = findViewById(R.id.btn7);
        btnEight = findViewById(R.id.btn8);
        btnNine = findViewById(R.id.btn9);
        btnStar = findViewById(R.id.btnS);
        btnHash = findViewById(R.id.btnH);
        btnCall = findViewById(R.id.btnC);

        input = findViewById(R.id.editText2);

        btnKey = findViewById(R.id.btnK);
        btnCT = findViewById(R.id.btnCT);
        btnCL = findViewById(R.id.btnCL);
        btnKey.setTextColor(Color.rgb(30,144,255));
        btnCL.setTextColor(Color.rgb(252,252,252));
        btnCT.setTextColor(Color.rgb(252,252,252));

        btnCL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openactivity2();
            }


        });
        btnCT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openactivity3();
            }


        });
        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onDial();
            }
        });
    }

    public void one(View v) {
        onButtonClick(btnOne, input, "1");
    }

    public void two(View v) {
        onButtonClick(btnTwo, input, "2");
    }

    public void three(View v) {
        onButtonClick(btnThree, input, "3");
    }

    public void four(View v) {
        onButtonClick(btnFour, input, "4");
    }

    public void five(View v) {
        onButtonClick(btnFive, input, "5");
    }

    public void six(View v) {
        onButtonClick(btnSix, input, "6");
    }

    public void seven(View v) {
        onButtonClick(btnSeven, input, "7");
    }

    public void eight(View v) {
        onButtonClick(btnEight, input, "8");
    }

    public void nine(View v) {
        onButtonClick(btnNine, input, "9");
    }

    public void zero(View v) {
        onButtonClick(btnZero, input, "0");
    }

    public void star(View v) {
        onButtonClick(btnStar, input, "*");
    }

    public void hash(View v) {
        onButtonClick(btnHash, input, "#");
    }

    public void del(View v) {
        input.setText("");
    }

 /*   public void onDial(View v) {

        if (input.getText().length() <= 3) {
            Toast.makeText(this, "Enter the Valid Number", Toast.LENGTH_SHORT).show();
        } else {
            Intent intent = new Intent(Intent.ACTION_CALL);
            String hash = input.getText().toString();
            if (hash.contains("#")) {
                hash.replace("#", "%23");
            }
            intent.setData(Uri.parse("tel:" + hash));

            if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            startActivity(intent);
        }
    }

  */


    public void onButtonClick(Button button, EditText inputNumber, String number){
        String cache = input.getText().toString();
        inputNumber.setText(cache +number);
        }


 private void onDial() {
     String number = input.getText().toString();
     if (input.getText().length() >= 3) {

         if (ContextCompat.checkSelfPermission(MainActivity.this,
                 Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
             ActivityCompat.requestPermissions(MainActivity.this,
                     new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL);
         } else {
             String dial = "tel:" + number;
             startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
         }

     } else {
         Toast.makeText(MainActivity.this, "Please Enter the Valid Number", Toast.LENGTH_SHORT).show();
     }
 }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CALL) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                onDial();
            } else {
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void openactivity2(){
        Intent intent = new Intent(this,Main2Activity.class);
        startActivity(intent);
    }
    public void openactivity3(){

        Intent intent = new Intent(this,Main3Activity.class);
        startActivity(intent);
    }
}
