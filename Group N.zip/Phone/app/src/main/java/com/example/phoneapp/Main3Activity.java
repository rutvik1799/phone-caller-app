package com.example.phoneapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

// Contacts

public class Main3Activity extends AppCompatActivity {
    Button btnKey2, btnCT2, btnCL2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.frag_contacts);

        btnKey2 = findViewById(R.id.btnK3);
        btnCT2 = findViewById(R.id.btnCT3);
        btnCL2 = findViewById(R.id.btnCL3);

        btnKey2.setTextColor(Color.rgb(252,252,252));
        btnCL2.setTextColor(Color.rgb(252,252,252));
        btnCT2.setTextColor(Color.rgb(30,144,255));

        btnKey2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openactivity();
            }


        });
        btnCL2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openactivity2();
            }


        });
    }
    public void openactivity(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
    public void openactivity2(){
        Intent intent = new Intent(this,Main2Activity.class);
        startActivity(intent);
    }
}
