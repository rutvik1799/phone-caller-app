package com.example.phoneapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.provider.CallLog;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Date;

public class Main2Activity extends AppCompatActivity {
    Button btnKey1, btnCT1, btnCL1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.frag_calls);
        btnKey1 = findViewById(R.id.btnK1);
        btnCT1 = findViewById(R.id.btnCT1);
        btnCL1 = findViewById(R.id.btnCL1);
        btnKey1.setTextColor(Color.rgb(252,252,252));
        btnCL1.setTextColor(Color.rgb(30,144,255));
        btnCT1.setTextColor(Color.rgb(252,252,252));

        btnKey1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openactivity();
            }


        });
        btnCT1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openactivity3();
            }


        });


        if(ContextCompat.checkSelfPermission(Main2Activity.this, Manifest.permission.READ_CALL_LOG)!= PackageManager.PERMISSION_GRANTED){
            if(ActivityCompat.shouldShowRequestPermissionRationale(Main2Activity.this,Manifest.permission.READ_CALL_LOG)){
                ActivityCompat.requestPermissions(Main2Activity.this,
                        new String[]{ Manifest.permission.READ_CALL_LOG},1);
            }else{
                ActivityCompat.requestPermissions(Main2Activity.this,
                        new String[]{ Manifest.permission.READ_CALL_LOG},1);
            }
        }else{
            TextView textView = (TextView) findViewById(R.id.textView);
            textView.setText(getCallDetails());
        }
    }
    public void onRequestPermissionResult(int requestCode,String[] permissions, int[] grantResults){
        switch(requestCode){
            case 1: {
                if(grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    if(ContextCompat.checkSelfPermission(Main2Activity.this,Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED){
                        Toast.makeText(this,"Permission Granted !",Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(this,"No Permission Granted !",Toast.LENGTH_SHORT).show();
                }return;
            }
        }
    }
    private String getCallDetails(){
        StringBuffer sb = new StringBuffer();
        Cursor managedCursor = getContentResolver().query(CallLog.Calls.CONTENT_URI,null,null,null,null,null);
        int number = managedCursor.getColumnIndex(CallLog.Calls.NUMBER);
        int type = managedCursor.getColumnIndex(CallLog.Calls.TYPE);
        int date = managedCursor.getColumnIndex(CallLog.Calls.DATE);
        int duration = managedCursor.getColumnIndex(CallLog.Calls.DURATION);
        sb.append("Call Details: \n\n");

        while (managedCursor.moveToNext()){
            String phNumber =  managedCursor.getString(number);
            String callType = managedCursor.getString(type);
            String callData = managedCursor.getString(date);
            Date callDayTime = new Date (Long.valueOf(callData));
            SimpleDateFormat formatter =  new SimpleDateFormat("dd-MM-yy HH:mm");
            String dateString = formatter.format(callDayTime);
            String callDuration = managedCursor.getString(duration);
            String dir =null;
            int dircode = Integer.parseInt(callType);
            switch(dircode){
                case CallLog.Calls.OUTGOING_TYPE:
                    dir = "OUTGOING";
                    break;
                case CallLog.Calls.INCOMING_TYPE:
                    dir = "INCOMING";
                    break;
                case CallLog.Calls.MISSED_TYPE:
                    dir = "MISSED";
                    break;
            }
            sb.append("\n Phone Number: "+phNumber+"\n Call Type: "+dir+"\n Call Date: "+dateString+
                    " \nCall Duration: "+callDuration);
            sb.append("\n-----------------------------");
        }
        managedCursor.close();
        return sb.toString();
    }
    public void openactivity(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
    public void openactivity3(){
        Intent intent = new Intent(this,Main3Activity.class);
        startActivity(intent);
    }

}


